<html><head>
	<script src="javascript/phaser.js"></script>
	<script src="javascript/playerClass.js"></script>
	<script src="javascript/zombiesClass.js"></script>
	<script src="javascript/game.js"></script>
</head><body></body></html>